/*!
 * Windows Phone 8
 */
conditionizr.add('winPhone8', function () {
    return /Windows Phone 8.0/i.test(navigator.userAgent);
});
