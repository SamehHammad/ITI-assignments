/*!
 * Windows Phone 7.5
 */
conditionizr.add('winPhone75', function () {
  return /Windows Phone 7.5/i.test(navigator.userAgent);
});
