/*!
 * Windows Phone 7
 */
conditionizr.add('winPhone7', function () {
    return /Windows Phone 7.0/i.test(navigator.userAgent);
});
